import { Card } from "./ui/card"
import { DonutChart } from "./charts/donut-chart"
import { LineChart } from "./charts/line-chart"

export default function MainBalance() {
  const earningData = [
    { name: "Income", value: 30, color: "#FF1493" },
    { name: "Expenses", value: 40, color: "#00F5FF" },
    { name: "Unknown", value: 10, color: "#E5E7EB" },
  ]

  const weeklyData = [
    { day: "Sun", value: 30 },
    { day: "Mon", value: 45 },
    { day: "Tue", value: 35 },
    { day: "Wed", value: 50 },
    { day: "Thu", value: 40 },
    { day: "Fri", value: 45 },
    { day: "Sat", value: 35 },
  ]

  return (
    <Card className="p-6 bg-pink-50">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-sm font-medium text-gray-500">Main Balance</h2>
          <p className="text-3xl font-bold mt-1">$673,412.66</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-500">VALID THRU</div>
          <div>08/21</div>
        </div>
      </div>
      
      <div className="flex justify-between items-center mb-6">
        <div>
          <div className="text-sm text-gray-500">CARD HOLDER</div>
          <div>Samantha Anderson</div>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-500">CARD NUMBER</div>
          <div>**** **** **** 1234</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div>
          <h3 className="text-sm font-medium mb-4">Earning Category</h3>
          <DonutChart data={earningData} />
        </div>
        <div>
          <LineChart data={weeklyData} />
        </div>
      </div>
    </Card>
  )
}


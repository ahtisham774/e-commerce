import { LineChart as RechartsLineChart, Line, XAxis, YAxis, ResponsiveContainer } from "recharts"

export function LineChart({ data }) {
  return (
    <ResponsiveContainer width="100%" height={200}>
      <RechartsLineChart data={data}>
        <XAxis dataKey="day" />
        <YAxis hide />
        <Line
          type="monotone"
          dataKey="value"
          stroke="#FF1493"
          strokeWidth={2}
          dot={false}
        />
      </RechartsLineChart>
    </ResponsiveContainer>
  )
}


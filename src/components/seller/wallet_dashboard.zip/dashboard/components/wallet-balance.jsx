import { Card } from "./ui/card"
import { Button } from "./ui/button"
import { Clock, Wallet } from 'lucide-react'

export default function WalletBalance() {
  return (
    <Card className="p-6 bg-pink-50">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-sm font-medium text-gray-500">Wallet Balance</h2>
        <div className="flex gap-2">
          <div className="w-4 h-4 rounded-full bg-pink-500"></div>
          <div className="w-4 h-4 rounded-full bg-gray-300"></div>
        </div>
      </div>
      
      <p className="text-3xl font-bold mb-2">$824,571.93</p>
      <p className="text-sm text-gray-500 mb-6">+0.8% from last week</p>

      <div className="grid grid-cols-2 gap-4">
        <Button className="bg-cyan-400 hover:bg-cyan-500 text-white">
          <Wallet className="w-4 h-4 mr-2" />
          Top Up
        </Button>
        <Button variant="outline" className="border-cyan-400 text-cyan-400 hover:bg-cyan-50">
          <Clock className="w-4 h-4 mr-2" />
          Withdraw
        </Button>
      </div>
    </Card>
  )
}


import { Card } from "./components/ui/card"
import { Button } from "./components/ui/button"
import { Badge } from "./components/ui/badge"
import MainBalance from "./components/main-balance"
import WalletBalance from "./components/wallet-balance"
import PaymentHistory from "./components/payment-history"
import OrdersSent from "./components/orders-sent"

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <MainBalance />
          </div>
          <div>
            <WalletBalance />
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <PaymentHistory />
          </div>
          <div>
            <OrdersSent />
          </div>
        </div>
      </div>
    </div>
  )
}

